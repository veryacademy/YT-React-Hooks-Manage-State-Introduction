import React, { useState } from 'react';
import "./products.css";


const products = [
  {
    img: '🧦',
    name: 'socks',
    price: 10
  },
  {
    img: '🧤',
    name: 'gloves',
    price: 20
  },
  {
    img: '👗',
    name: 'dress',
    price: 50
  },
]

function getTotal(total){
  return total.toLocaleString(undefined, {minimumFractionDigits:2,maximumFractionDigits:2})
}

export default function Products() {
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);

  function add(item){
    setCart(current =>[...current, item.name]);
    setTotal(current => current + item.price);
  }

  return (
    <div className="container">
        <div>Total Items:{cart.length}</div>
        <div>Total Cost:{getTotal(total)}</div>
      <div className="products">
      {products.map(item => (
          <div key={item.name}>
            <div className="product">
              <span role="img" aria-label={item.name}>{item.img}</span>
            </div>
            <button onClick={() => add(item)}>Add</button>
            <button>Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
}