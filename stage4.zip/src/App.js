import React from 'react';
import Products from './components/store/Products';

function App() {
  return <Products />
}

export default App;