import React, { useState } from 'react';
import "./products.css";

function getTotal(total){
  return total.toLocaleString(undefined, {minimumFractionDigits:2,maximumFractionDigits:2})
}

export default function Products() {
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);

  function add(){
    setCart(['Socks']);
    setTotal(10);
  }

  return (
    <div className="container">
        <div>Total Items:{cart.length}</div>
        <div>Total Cost:{getTotal(total)}</div>
      <div className="products">
          <span role="img" aria-label="socks">
            🧦
          </span>
        <button onClick={add}>Add</button> 
        <button onClick={() =>{
          setCart([]);
          setTotal(0)
        }}>Remove</button>
      </div>
    </div>
  );
}