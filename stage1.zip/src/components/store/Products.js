import React from "react";
import "./products.css";

export default function Products() {
  return (
    <div className="container">
        <div>Total Items: 0</div>
        <div>Total Cost: 0</div>
      <div className="products">
          <span role="img" aria-label="socks">
            🧦
          </span>
        <button>Add</button> <button>Remove</button>
      </div>
    </div>
  );
}